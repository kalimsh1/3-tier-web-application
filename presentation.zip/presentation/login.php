<!DOCTYPE html>
<html>
<head>
  <title>Login - SkillSwap Hub</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php include 'header.html'; ?>
  <div class="container">
    <h2>Login</h2>
    <form action="../business/login.php" method="post">
      <label>Email:</label><br>
      <input type="email" name="email" required><br>
      <label>Password:</label><br>
      <input type="password" name="password" required><br><br>
      <input type="submit" value="Login">
    </form>
  </div>
  <?php include 'footer.html'; ?>
</body>
</html>
