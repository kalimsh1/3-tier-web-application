<?php
session_start();
require_once '../data/Database.php';
require_once 'Message.php';
require_once 'User.php';
use SkillSwap\Data\Database;
use SkillSwap\Business\Message;
use SkillSwap\Business\User;

$from = $_SESSION['user'] ?? null;
$to = $_POST['to'] ?? null;
$message = $_POST['message'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Message Status</title>
    <link rel="stylesheet" href="../presentation/style.css">
</head>
<body>
    <?php include '../presentation/header.html'; ?>
    <div class="container">
        <h2>Message Status</h2>
        <?php
        $db = new Database();
        $userService = new User($db);

        // Validate sender and recipient exist
        $errors = [];
        if (!$from) {
            $errors[] = "You must be logged in to send a message.";
        } else {
            $stmt = $db->getConnection()->prepare("SELECT email FROM users WHERE email = ?");
            $stmt->execute([$from]);
            if (!$stmt->fetch()) {
                $errors[] = "Sender email ($from) is not registered.";
            }
        }
        if ($to) {
            $stmt = $db->getConnection()->prepare("SELECT email FROM users WHERE email = ?");
            $stmt->execute([$to]);
            if (!$stmt->fetch()) {
                $errors[] = "Recipient email ($to) is not registered.";
            }
        } else {
            $errors[] = "Recipient email is missing.";
        }
        if (!$message) {
            $errors[] = "Message content is missing.";
        }

        if (empty($errors)) {
            $msgService = new Message($db);
            if ($msgService->send($from, $to, $message)) {
                echo "<p class='success'>✅ Message sent!</p>";
            } else {
                echo "<p class='error'>❌ Failed to send message.</p>";
            }
        } else {
            echo "<p class='error'>❌ Cannot send message:</p><ul>";
            foreach ($errors as $error) {
                echo "<li>$error</li>";
            }
            echo "</ul>";
        }
        ?>
        <a href="../presentation/dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
    <?php include '../presentation/footer.html'; ?>
</body>
</html>
?>