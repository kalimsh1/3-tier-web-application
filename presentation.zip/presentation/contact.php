<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$to = $_GET['to'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact User</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.html'; ?>

    <div class="container">
        <h2>Send a Message</h2>
        <form action="../business/send_message.php" method="post">
            <input type="hidden" name="to" value="<?php echo htmlspecialchars($to); ?>">
            <label for="message">Your Message:</label>
            <textarea name="message" rows="5" required></textarea>
            <button type="submit">Send Message</button>
        </form>
        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>

    <?php include 'footer.html'; ?>
</body>
</html>