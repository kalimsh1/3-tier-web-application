<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inbox</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.html'; ?>
    <div class="container">
        <h2>Your Inbox</h2>
        <?php include '../business/get_messages.php'; ?>
        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
    <?php include 'footer.html'; ?>
</body>
</html>
?>