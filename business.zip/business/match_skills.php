<?php
session_start();
require_once '../data/Database.php';
require_once '../business/SkillMatcher.php';
use SkillSwap\Data\Database;
use SkillSwap\Business\SkillMatcher;

$currentUser = $_SESSION['user'] ?? null;
if ($currentUser) {
    $db = new Database();
    $matcher = new SkillMatcher($db);
    $matches = $matcher->getMatches($currentUser);
    foreach ($matches as $row) {
        echo "<p><strong>{$row['name']}</strong><br>Skill: {$row['skill']}<br>";
        echo "<a href='../presentation/contact.php?to=" . urlencode($row['email']) . "'>Contact</a></p><hr>";
    }
} else {
    echo "<p>Please log in to view skill matches.</p>";
}
?>