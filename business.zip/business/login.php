<?php
session_start();
require_once '../data/Database.php';
require_once '../business/User.php';
use SkillSwap\Data\Database;
use SkillSwap\Business\User;

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

$db = new Database();
$userService = new User($db);
if ($loggedInEmail = $userService->login($email, $password)) {
    session_regenerate_id(true);
    $_SESSION['user'] = $loggedInEmail;
    header("Location: ../presentation/dashboard.php");
    exit();
} else {
    header("Location: ../presentation/login.php?error=Invalid+email+or+password");
    exit();
}
?>