<!DOCTYPE html>
<html>
<head>
  <title>Register - SkillSwap Hub</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php include 'header.html'; ?>
  <div class="container">
    <h2>Register</h2>
    <form action="../business/register.php" method="post">
      <label>Name:</label><br>
      <input type="text" name="name" required><br>
      <label>Email:</label><br>
      <input type="email" name="email" required><br>
      <label>Password:</label><br>
      <input type="password" name="password" required><br>
      <label>Your Skill:</label><br>
      <input type="text" name="skill" required><br><br>
      <input type="submit" value="Register">
    </form>
  </div>
  <?php include 'footer.html'; ?>
</body>
</html>
