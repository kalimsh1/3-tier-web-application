<!DOCTYPE html>
<html>
<head>
  <title>Dashboard - SkillSwap Hub</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php include 'header.html'; ?>
  <div class="container">
    <h2>Your Dashboard</h2>
    <p>Welcome to your skill exchange dashboard.</p>
    <div id="skill-matches">
      <?php include '../business/match_skills.php'; ?>
    </div>
  </div>
  <?php include 'footer.html'; ?>
</body>
</html>
