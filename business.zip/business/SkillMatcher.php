<?php
namespace SkillSwap\Business;

use SkillSwap\Data\Database;

class SkillMatcher {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db->getConnection();
    }

    public function getMatches($currentUserEmail) {
        $stmt = $this->db->prepare("SELECT name, skill, email FROM users WHERE email != ?");
        $stmt->execute([$currentUserEmail]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
?>