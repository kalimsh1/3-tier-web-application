<?php
namespace SkillSwap\Business;

use SkillSwap\Data\Database;

class Message {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db->getConnection();
    }

    public function send($from, $to, $message) {
        $stmt = $this->db->prepare("INSERT INTO messages (sender_email, recipient_email, message, sent_at) VALUES (?, ?, ?, NOW())");
        return $stmt->execute([$from, $to, $message]);
    }

    public function getMessages($recipientEmail) {
        $stmt = $this->db->prepare("SELECT sender_email, message, sent_at FROM messages WHERE recipient_email = ? ORDER BY sent_at DESC");
        $stmt->execute([$recipientEmail]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
?>