<?php
namespace SkillSwap\Business;

use SkillSwap\Data\Database;

class User {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db->getConnection();
    }

    public function register($name, $email, $password, $skill) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->db->prepare("INSERT INTO users (name, email, password, skill) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$name, $email, $hashedPassword, $skill]);
    }

    public function login($email, $password) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            return $user['email'];
        }
        return false;
    }
}
?>