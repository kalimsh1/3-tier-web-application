<?php
namespace SkillSwap\Data;

class Database {
    private $conn;
    private $host = "localhost";
    private $dbname = "skillswap";
    private $username = "root";
    private $password = "";

    public function __construct() {
        try {
            $this->conn = new \PDO("mysql:host=$this->host;dbname=$this->dbname", $this->username, $this->password);
            $this->conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            error_log("Connection failed: " . $e->getMessage());
            throw new \Exception("Unable to connect to the database: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->conn;
    }
}
?>
