<?php
require_once '../data/Database.php';
require_once 'Message.php';
use SkillSwap\Data\Database;
use SkillSwap\Business\Message;

$currentUser = $_SESSION['user'] ?? null;
if ($currentUser) {
    $db = new Database();
    $msgService = new Message($db);
    $messages = $msgService->getMessages($currentUser);
    if (count($messages) > 0) {
        foreach ($messages as $row) {
            echo "<div class='message-box'>";
            echo "<p><strong>From:</strong> " . htmlspecialchars($row['sender_email']) . "</p>";
            echo "<p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($row['message'])) . "</p>";
            echo "<p><small>Sent at: " . htmlspecialchars($row['sent_at']) . "</small></p>";
            echo "</div><hr>";
        }
    } else {
        echo "<p>No messages found in your inbox.</p>";
    }
} else {
    echo "<p>You must be logged in to see your messages.</p>";
}
?>