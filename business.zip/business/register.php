<?php
require_once '../data/Database.php';
require_once '../business/User.php';
use SkillSwap\Data\Database;
use SkillSwap\Business\User;

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$skill = $_POST['skill'] ?? '';

$db = new Database();
$userService = new User($db);
if ($userService->register($name, $email, $password, $skill)) {
    header("Location: ../presentation/login.php?success=Registration+successful");
    exit();
} else {
    header("Location: ../presentation/register.php?error=Registration+failed");
    exit();
}
?>