<!DOCTYPE html>
<html>
<head>
  <title>Home - SkillSwap Hub</title>


  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php include 'header.html'; ?>
  <div class="container">
    <h2>Welcome to SkillSwap Hub!</h2>
    <p>Connect and exchange skills with others in your community.</p>
  </div>
  <?php include 'footer.html'; ?>
</body>
</html>
